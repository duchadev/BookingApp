import { Link, useLocation } from "react-router-dom"; // Import useLocation
import "../assets/css/AdminDashboard.css";
import { isAuthenticated } from "../auth";

const DashboardMenu = () => {
    const location = useLocation(); // Get the current location
    const {
        user: { name, email, role }
    } = isAuthenticated();
    return (
        <div className="admin-menu">
            <div className="admin-profile">
                <div className="profile-info">
                    <h2>{name}</h2>
                    <p>{email}</p>
                    <span className="role-badge">
                        {role === 1 ? 'Administrator' : 'User'}
                    </span>
                </div>
            </div>
            <nav className="admin-nav">
                <Link to="/admin/dashboard" className={`nav-itemx ${location.pathname === "/admin/dashboard" ? "active" : ""}`}>
                    <i className="fas fa-chart-line"></i>
                    Dashboard
                </Link>
                <Link to="/create/category" className={`nav-itemx ${location.pathname === "/create/category" ? "active" : ""}`}>
                    <i className="fas fa-folder-plus"></i>
                    Create Category
                </Link>
                {/* <Link to="/create/product" className={`nav-item ${location.pathname === "/create/product" ? "active" : ""}`}>
                    <i className="fas fa-plus-circle"></i>
                    Create Place
                </Link> */}
                <Link to="/admin/orders" className={`nav-itemx ${location.pathname === "/admin/orders" ? "active" : ""}`}>
                    <i className="fas fa-shopping-cart"></i>
                    View Orders
                </Link>
                <Link to="/admin/products" className={`nav-itemx ${location.pathname === "/admin/products" ? "active" : ""}`}>
                    <i className="fas fa-boxes"></i>
                    Manage Places
                </Link>
                <Link to="/admin/users" className={`nav-itemx ${location.pathname === "/admin/users" ? "active" : ""}`}>
                    <i className="fas fa-users-cog"></i>
                    Manage Users
                </Link>
            </nav>
        </div>
    );
};
export default DashboardMenu;
