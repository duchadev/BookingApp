import React, { useState, useEffect } from 'react';
import Layout from "../core/Layout";
import * as apiClient from "../api-client";
import { getUsers, getProducts, listOrders } from '../admin/apiAdmin'; 
import "../assets/css/AdminDashboard.css";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import DashboardMenu from "./DashboardMenu";

const Dashboard = () => {
    const [stats, setStats] = useState({
        totalUsers: 0,
        totalProducts: 0,
        totalOrders: 0,
        totalRevenue: 0,
        totalItemsSold: 0,
        revenueData: []
    });

    const {
        user: { name }
    } = isAuthenticated();

    const fetchDashboardData = async () => {
        try {
            const [usersRes, productsRes, ordersRes] = await Promise.all([
                getUsers(isAuthenticated().user._id, isAuthenticated().token),
                getProducts(),
                listOrders(isAuthenticated().user._id, isAuthenticated().token)
            ]);

            // Calculate total revenue and total items sold from orders
            const totalRevenue = ordersRes.reduce((acc, order) => acc + (order.amount || 0), 0);
            const totalItemsSold = ordersRes.reduce((acc, order) => acc + (order.products.length ? order.products.reduce((prodAcc, product) => prodAcc + product.count, 0) : 0), 0);
            const revenueData = ordersRes.map(order => ({
                date: new Date(order.createdAt).toLocaleDateString('en-GB'), 
                amount: order.amount
            }));
            return {
                totalUsers: usersRes.length,
                totalProducts: productsRes.length,
                totalOrders: ordersRes.length,
                totalRevenue,
                totalItemsSold,
                revenueData
            };
        } catch (error) {
            console.error('Error fetching dashboard data:', error);
            return {
                totalUsers: 0,
                totalProducts: 0,
                totalOrders: 0,
                totalRevenue: 0,
                totalItemsSold: 0,
                revenueData: []
            };
        }
    };

    // Fetch dashboard data on component mount
    useEffect(() => {
        const getDashboardStats = async () => {
            const stats = await fetchDashboardData();
            setStats(stats);
        };

        getDashboardStats();
    }, []);

    const StatCard = ({ icon, title, value, color }) => (
        <div className="stat-card" style={{ borderColor: color }}>
            <i className={`fas ${icon}`} style={{ color }}></i>
            <div className="stat-info">
                <h3>{title}</h3>
                <h2>{value}</h2>
            </div>
        </div>
    );

    const chartData = stats.revenueData.map(data => ({
        date: data.date,
        amount: data.amount,
    }));
    const CustomTooltip = ({ active, payload }) => {
        if (active && payload && payload.length) {
            const formattedDate = payload[0].payload.date; // This should now be the formatted date string
            // Inline styles for the tooltip
            const tooltipStyle = {
                backgroundColor: '#ffffff', // White background
                border: '1px solid #6f42c1', // Green border
                borderRadius: '10px', // Rounded corners
                padding: '10px 15px', // Padding
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)', // Subtle shadow
                fontFamily: 'Arial, sans-serif', // Font family
                zIndex: 1000, // Ensure tooltip is on top
                transition: 'all 0.3s ease', // Smooth transition
            };
    
            const labelStyle = {
                fontWeight: 'bold', // Bold label
                color: '#333', // Dark gray text
                marginBottom: '3px', // Reduced bottom margin
            };
    
            const amountStyle = {
                fontSize: '1.1em', // Larger font for amount
                color: '#dc3545', // Match color with the chart line
                margin: 0, // Remove any margin below the amount
                fontStyle: 'italic', //
            };
    
            return (
                <div style={tooltipStyle}>
                    <p style={labelStyle}>{`Date: ${formattedDate}`}</p>
                    <p style={amountStyle}>{`Amount: $${payload[0].value.toLocaleString()}`}</p>
                </div>
            );
        }
        return null;
    };
    const formatYAxisValue = (value) => {
        return `$${value.toLocaleString()}`;
    };
    
    return (
        <Layout
            title="Admin Dashboard"
            description={`Welcome back, ${name}!`}
            className="dashboard-layout"
        >
            <div className="dashboard-container">
                <DashboardMenu />
                <main className="dashboard-main">
                    <div className="stats-grid">
                        <StatCard
                            icon="fa-box"
                            title="Total Products"
                            value={stats.totalProducts.toLocaleString()}
                            color="#4CAF50"
                        />
                        <StatCard
                            icon="fa-shopping-cart"
                            title="Total Bookings"
                            value={stats.totalOrders.toLocaleString()}
                            color="#2196F3"
                        />
                        <StatCard
                            icon="fa-users"
                            title="Total Users"
                            value={stats.totalUsers.toLocaleString()}
                            color="#9C27B0"
                        />
                        <StatCard
                            icon="fa-dollar-sign"
                            title="Total Revenue"
                            value={`$${stats.totalRevenue.toLocaleString()}`} // Format total revenue
                            color="#F44336"
                        />
                    </div>

                    <div className="dashboard-charts">
                        <div className="chart-container">
                            <h3>Revenue Overview</h3>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={chartData}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="date" tickFormatter={(date) => date} />
                                    <YAxis  tickFormatter={formatYAxisValue} />
                                    <Tooltip content={<CustomTooltip />} />
                                    <Line type="monotone" dataKey="amount" stroke="#4CAF50" activeDot={{ r: 8 }} />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>

                        <div className="summary-container">
                            <h3>Quick Summary</h3>
                            <div className="summary-content">
                                <div className="summary-item">
                                    <span>Total Rooms Booked</span>
                                    <strong>{stats.totalItemsSold.toLocaleString()}</strong>
                                </div>
                                <div className="summary-item m-0">
                                    <span>Average Booking Value (%)</span>
                                    <strong>
                                        {stats.totalOrders > 0 ?
                                            ((stats.totalRevenue / stats.totalOrders) / stats.totalRevenue * 100).toFixed(2)
                                            : 0}%
                                    </strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </Layout>
    );
};

export default Dashboard;
