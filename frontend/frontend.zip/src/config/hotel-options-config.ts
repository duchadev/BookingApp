export const hotelTypes = ["Hotel", "Resort", "Apartment", "Villa", "Cabin"];

export const hotelFacilities = [
  "Free WiFi",
  "Parking",
  "Airport Shuttle",
  "Family Rooms",
  "Non-Smoking Rooms",
  "Outdoor Pool",
  "Spa",
  "Fitness Center",
];
