export const roomFacilities = [
  "Desk",
  "Coffee machine",
  "Dining table",
  "Wake-up service",
  "Safe",
  "Flat-screen TV",
  "Drying rack for clothing",
  "Iron",
  "Towels",
  "Fan",
];
